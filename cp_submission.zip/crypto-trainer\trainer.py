import os
import pickle
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from cryptotrainer.utils import preprocess_data
import mlflow

DATA_PATH = "/app/data/processed"       # mounted from host
MODEL_PATH = os.environ.get("MODEL_OUTPUT_PATH", "/app/models/model_latest.pkl")
MLFLOW_URI = os.environ.get("MLFLOW_TRACKING_URI", "http://mlflow:5000")


def load_latest_features():
    """Load the most recent parquet feature file."""
    print("Looking for parquet files in:", DATA_PATH)

    files = [f for f in os.listdir(DATA_PATH) if f.endswith(".parquet")]
    if not files:
        raise FileNotFoundError("No parquet feature files found.")

    files.sort()  # chronological order
    latest = files[-1]
    print("Loading latest feature file:", latest)

    df = pd.read_parquet(os.path.join(DATA_PATH, latest))
    return df


def train_model():
    print("Starting training...")

    mlflow.set_tracking_uri(MLFLOW_URI)
    mlflow.set_experiment("crypto_volatility")

    df = load_latest_features()
    df = preprocess_data(df)

    # Simple numeric model: predict mid_return volatility
    X = df[["midprice", "spread", "trade_intensity"]].fillna(0)
    y = df["volatility_30s"].fillna(0)

    model = RandomForestRegressor(n_estimators=50)

    with mlflow.start_run():
        print("Training model...")
        model.fit(X, y)

        score = model.score(X, y)
        print("Training R^2:", score)

        mlflow.log_metric("train_r2", score)

        # Save model locally
        print("Saving model to:", MODEL_PATH)
        with open(MODEL_PATH, "wb") as f:
            pickle.dump(model, f)

        mlflow.log_artifact(MODEL_PATH)


if __name__ == "__main__":
    try:
        train_model()
        print("Training completed successfully.")
    except Exception as e:
        print("Training failed:", e)
        raise
