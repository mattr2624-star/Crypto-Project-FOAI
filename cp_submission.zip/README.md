# Crypto Pipeline (cp)

This is a cryptocurrency data pipeline with Kafka streaming, MLflow tracking, and training modules.

## Structure
- `crypto-trainer/`: Training logic
- `crypto-producer/`: Kafka producer
- `crypto-consumer/`: Kafka consumer
- `crypto-stream/`: Streaming logic
- `mlflow/`: MLflow server Docker setup
