# crypto-trainer package initialization
