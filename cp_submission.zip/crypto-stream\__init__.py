# crypto-stream package initialization
