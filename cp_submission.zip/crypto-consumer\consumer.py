from kafka import KafkaConsumer

class CryptoConsumer:
    def __init__(self, topic, bootstrap_servers):
        self.consumer = KafkaConsumer(topic, bootstrap_servers=bootstrap_servers)

    def consume(self):
        for message in self.consumer:
            print(f"Received message: {message.value.decode()}")
