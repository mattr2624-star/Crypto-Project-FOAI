from kafka import KafkaProducer

class CryptoProducer:
    def __init__(self, bootstrap_servers):
        self.producer = KafkaProducer(bootstrap_servers=bootstrap_servers)

    def send(self, topic, message):
        self.producer.send(topic, value=message.encode())
        self.producer.flush()
        print(f"Sent message to {topic}: {message}")
