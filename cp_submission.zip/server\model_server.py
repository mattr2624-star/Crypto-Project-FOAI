from fastapi import FastAPI
from fastapi.responses import JSONResponse, Response
from prometheus_client import Counter, generate_latest, CONTENT_TYPE_LATEST, REGISTRY
import joblib
import os
from kafka import KafkaProducer
import json
from datetime import datetime

app = FastAPI(title="Crypto Model Server")

MODEL_PATH = "/app/models/model_latest.pkl"
KAFKA_BROKER = os.environ.get("KAFKA_BROKER", "cp-kafka-1:9092")
TOPIC = os.environ.get("TOPIC", "model-events")

# Metrics
model_requests = Counter("model_requests_total", "Total number of prediction requests")
model_retrains = Counter("model_retrains_total", "Total number of model retrains")

# Load model
model = None
if os.path.exists(MODEL_PATH):
    model = joblib.load(MODEL_PATH)

# Kafka producer
producer = KafkaProducer(
    bootstrap_servers=KAFKA_BROKER,
    value_serializer=lambda v: json.dumps(v).encode("utf-8")
)

@app.get("/health")
def health():
    return {
        "status": "ok",
        "model_loaded": model is not None,
        "model_path": MODEL_PATH,
        "kafka_broker": KAFKA_BROKER,
        "topic": TOPIC,
    }

@app.get("/metrics")
def metrics():
    return Response(generate_latest(REGISTRY), media_type=CONTENT_TYPE_LATEST)

@app.post("/predict")
def predict(data: dict):
    global model
    model_requests.inc()
    if model is None:
        return JSONResponse(status_code=503, content={"error": "model not loaded"})
    X = data.get("features")
    y_pred = model.predict([X])
    return {"prediction": y_pred.tolist()}

@app.post("/retrain")
def retrain(data: dict):
    global model
    model_retrains.inc()
    # Placeholder for retraining logic
    model_path = MODEL_PATH
    event = {
        "event": "model_retrained",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "model_path": model_path,
        "metrics": data.get("metrics", {})
    }
    producer.send(TOPIC, event)
    return {"status": "retrained", "model_path": model_path}
