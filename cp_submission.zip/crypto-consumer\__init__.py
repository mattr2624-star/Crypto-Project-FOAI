# crypto-consumer package initialization
